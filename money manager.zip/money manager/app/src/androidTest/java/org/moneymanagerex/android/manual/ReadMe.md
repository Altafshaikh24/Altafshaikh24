UI Tests here depend on a certain setup of the environment.
All the specifics are to be listed here.